<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType BrandNameType
 * @xmlName BrandName
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\BrandName
 */
class BrandName extends BrandNameType
{
} // end class BrandName
