<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType HazardClassIDType
 * @xmlName HazardClassID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\HazardClassID
 */
class HazardClassID extends HazardClassIDType
{
} // end class HazardClassID
