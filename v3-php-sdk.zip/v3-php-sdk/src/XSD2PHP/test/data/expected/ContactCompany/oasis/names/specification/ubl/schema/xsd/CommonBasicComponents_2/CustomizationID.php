<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType CustomizationIDType
 * @xmlName CustomizationID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\CustomizationID
 */
class CustomizationID extends CustomizationIDType
{
} // end class CustomizationID
