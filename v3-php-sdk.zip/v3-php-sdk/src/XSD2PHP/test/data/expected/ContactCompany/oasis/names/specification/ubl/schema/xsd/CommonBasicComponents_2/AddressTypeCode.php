<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType AddressTypeCodeType
 * @xmlName AddressTypeCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\AddressTypeCode
 */
class AddressTypeCode extends AddressTypeCodeType
{
} // end class AddressTypeCode
