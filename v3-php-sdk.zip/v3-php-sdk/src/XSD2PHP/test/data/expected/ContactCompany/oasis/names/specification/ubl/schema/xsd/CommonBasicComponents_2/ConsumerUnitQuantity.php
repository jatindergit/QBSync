<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ConsumerUnitQuantityType
 * @xmlName ConsumerUnitQuantity
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\ConsumerUnitQuantity
 */
class ConsumerUnitQuantity extends ConsumerUnitQuantityType
{
} // end class ConsumerUnitQuantity
