<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType CountrySubentityCodeType
 * @xmlName CountrySubentityCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\CountrySubentityCode
 */
class CountrySubentityCode extends CountrySubentityCodeType
{
} // end class CountrySubentityCode
