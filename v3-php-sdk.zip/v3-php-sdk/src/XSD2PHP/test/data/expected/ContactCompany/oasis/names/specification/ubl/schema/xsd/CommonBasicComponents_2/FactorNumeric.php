<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType FactorNumericType
 * @xmlName FactorNumeric
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\FactorNumeric
 */
class FactorNumeric extends FactorNumericType
{
} // end class FactorNumeric
