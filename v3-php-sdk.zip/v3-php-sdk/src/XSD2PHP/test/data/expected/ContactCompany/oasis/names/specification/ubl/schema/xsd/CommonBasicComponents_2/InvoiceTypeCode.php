<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType InvoiceTypeCodeType
 * @xmlName InvoiceTypeCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\InvoiceTypeCode
 */
class InvoiceTypeCode extends InvoiceTypeCodeType
{
} // end class InvoiceTypeCode
