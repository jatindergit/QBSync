<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType DegreesMeasureType
 * @xmlName DegreesMeasure
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\DegreesMeasure
 */
class DegreesMeasure extends DegreesMeasureType
{
} // end class DegreesMeasure
