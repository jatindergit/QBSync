<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ExpiryDateType
 * @xmlName ExpiryDate
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\ExpiryDate
 */
class ExpiryDate extends ExpiryDateType
{
} // end class ExpiryDate
