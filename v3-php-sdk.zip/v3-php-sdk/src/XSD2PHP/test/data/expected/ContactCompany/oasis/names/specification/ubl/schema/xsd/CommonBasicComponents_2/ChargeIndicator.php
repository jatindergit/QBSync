<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ChargeIndicatorType
 * @xmlName ChargeIndicator
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\ChargeIndicator
 */
class ChargeIndicator extends ChargeIndicatorType
{
} // end class ChargeIndicator
