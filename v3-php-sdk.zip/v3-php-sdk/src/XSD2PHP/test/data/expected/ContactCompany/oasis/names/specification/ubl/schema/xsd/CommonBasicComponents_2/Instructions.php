<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType InstructionsType
 * @xmlName Instructions
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\Instructions
 */
class Instructions extends InstructionsType
{
} // end class Instructions
