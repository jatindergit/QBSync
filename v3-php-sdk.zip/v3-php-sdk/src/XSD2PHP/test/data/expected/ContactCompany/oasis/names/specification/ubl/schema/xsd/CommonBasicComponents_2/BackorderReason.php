<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType BackorderReasonType
 * @xmlName BackorderReason
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\BackorderReason
 */
class BackorderReason extends BackorderReasonType
{
} // end class BackorderReason
