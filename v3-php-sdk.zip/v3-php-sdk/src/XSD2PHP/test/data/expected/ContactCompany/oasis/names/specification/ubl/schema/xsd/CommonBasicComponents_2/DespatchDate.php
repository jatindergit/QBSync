<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType DespatchDateType
 * @xmlName DespatchDate
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\DespatchDate
 */
class DespatchDate extends DespatchDateType
{
} // end class DespatchDate
