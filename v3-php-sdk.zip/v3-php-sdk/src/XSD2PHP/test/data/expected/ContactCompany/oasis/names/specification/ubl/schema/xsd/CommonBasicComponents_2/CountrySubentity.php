<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType CountrySubentityType
 * @xmlName CountrySubentity
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\CountrySubentity
 */
class CountrySubentity extends CountrySubentityType
{
} // end class CountrySubentity
