<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType DebitLineAmountType
 * @xmlName DebitLineAmount
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\DebitLineAmount
 */
class DebitLineAmount extends DebitLineAmountType
{
} // end class DebitLineAmount
