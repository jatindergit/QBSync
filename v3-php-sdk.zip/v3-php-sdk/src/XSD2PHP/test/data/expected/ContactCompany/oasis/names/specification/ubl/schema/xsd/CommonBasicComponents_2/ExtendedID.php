<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ExtendedIDType
 * @xmlName ExtendedID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\ExtendedID
 */
class ExtendedID extends ExtendedIDType
{
} // end class ExtendedID
