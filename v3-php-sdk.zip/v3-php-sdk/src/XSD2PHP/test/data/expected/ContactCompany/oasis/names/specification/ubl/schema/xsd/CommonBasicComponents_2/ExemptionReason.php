<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ExemptionReasonType
 * @xmlName ExemptionReason
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\ExemptionReason
 */
class ExemptionReason extends ExemptionReasonType
{
} // end class ExemptionReason
