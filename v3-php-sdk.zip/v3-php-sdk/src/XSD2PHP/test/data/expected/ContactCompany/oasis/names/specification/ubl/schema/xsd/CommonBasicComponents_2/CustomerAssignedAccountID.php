<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType CustomerAssignedAccountIDType
 * @xmlName CustomerAssignedAccountID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\CustomerAssignedAccountID
 */
class CustomerAssignedAccountID extends CustomerAssignedAccountIDType
{
} // end class CustomerAssignedAccountID
