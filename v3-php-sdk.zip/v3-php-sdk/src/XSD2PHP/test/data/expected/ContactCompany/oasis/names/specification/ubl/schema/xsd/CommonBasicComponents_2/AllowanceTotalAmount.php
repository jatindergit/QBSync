<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType AllowanceTotalAmountType
 * @xmlName AllowanceTotalAmount
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\AllowanceTotalAmount
 */
class AllowanceTotalAmount extends AllowanceTotalAmountType
{
} // end class AllowanceTotalAmount
