<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType InvoiceAmountType
 * @xmlName InvoiceAmount
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\InvoiceAmount
 */
class InvoiceAmount extends InvoiceAmountType
{
} // end class InvoiceAmount
