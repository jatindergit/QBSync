<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType GrossWeightMeasureType
 * @xmlName GrossWeightMeasure
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\GrossWeightMeasure
 */
class GrossWeightMeasure extends GrossWeightMeasureType
{
} // end class GrossWeightMeasure
