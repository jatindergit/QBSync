<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType InstructionType
 * @xmlName Instruction
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\Instruction
 */
class Instruction extends InstructionType
{
} // end class Instruction
