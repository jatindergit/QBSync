<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType LogoReferenceIDType
 * @xmlName LogoReferenceID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\LogoReferenceID
 */
class LogoReferenceID extends LogoReferenceIDType
{
} // end class LogoReferenceID
