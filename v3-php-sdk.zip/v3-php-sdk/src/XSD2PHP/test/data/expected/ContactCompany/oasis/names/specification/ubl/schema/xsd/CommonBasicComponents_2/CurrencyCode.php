<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType CurrencyCodeType
 * @xmlName CurrencyCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\CurrencyCode
 */
class CurrencyCode extends CurrencyCodeType
{
} // end class CurrencyCode
