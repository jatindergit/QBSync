<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType MarkCareIndicatorType
 * @xmlName MarkCareIndicator
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\MarkCareIndicator
 */
class MarkCareIndicator extends MarkCareIndicatorType
{
} // end class MarkCareIndicator
