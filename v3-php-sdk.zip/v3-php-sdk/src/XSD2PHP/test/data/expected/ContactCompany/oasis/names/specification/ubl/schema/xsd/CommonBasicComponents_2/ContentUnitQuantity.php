<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ContentUnitQuantityType
 * @xmlName ContentUnitQuantity
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\ContentUnitQuantity
 */
class ContentUnitQuantity extends ContentUnitQuantityType
{
} // end class ContentUnitQuantity
