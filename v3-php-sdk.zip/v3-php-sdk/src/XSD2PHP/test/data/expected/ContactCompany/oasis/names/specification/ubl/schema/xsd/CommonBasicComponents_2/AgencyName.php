<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType AgencyNameType
 * @xmlName AgencyName
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\AgencyName
 */
class AgencyName extends AgencyNameType
{
} // end class AgencyName
