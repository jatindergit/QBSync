<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType CV2IDType
 * @xmlName CV2ID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\CV2ID
 */
class CV2ID extends CV2IDType
{
} // end class CV2ID
