<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType InformationType
 * @xmlName Information
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\Information
 */
class Information extends InformationType
{
} // end class Information
