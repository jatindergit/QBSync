<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType KeywordType
 * @xmlName Keyword
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\Keyword
 */
class Keyword extends KeywordType
{
} // end class Keyword
