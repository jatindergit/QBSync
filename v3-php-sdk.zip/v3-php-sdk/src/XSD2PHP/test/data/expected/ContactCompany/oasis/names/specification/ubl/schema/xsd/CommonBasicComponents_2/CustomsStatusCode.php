<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType CustomsStatusCodeType
 * @xmlName CustomsStatusCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\CustomsStatusCode
 */
class CustomsStatusCode extends CustomsStatusCodeType
{
} // end class CustomsStatusCode
