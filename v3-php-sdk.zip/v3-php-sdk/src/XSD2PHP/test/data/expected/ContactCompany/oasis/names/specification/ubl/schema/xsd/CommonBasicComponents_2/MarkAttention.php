<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType MarkAttentionType
 * @xmlName MarkAttention
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\MarkAttention
 */
class MarkAttention extends MarkAttentionType
{
} // end class MarkAttention
