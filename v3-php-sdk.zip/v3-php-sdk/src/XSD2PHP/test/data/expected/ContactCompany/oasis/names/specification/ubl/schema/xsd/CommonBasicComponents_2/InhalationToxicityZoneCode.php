<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType InhalationToxicityZoneCodeType
 * @xmlName InhalationToxicityZoneCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\InhalationToxicityZoneCode
 */
class InhalationToxicityZoneCode extends InhalationToxicityZoneCodeType
{
} // end class InhalationToxicityZoneCode
