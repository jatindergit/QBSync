<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType CertificateTypeType
 * @xmlName CertificateType
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\CertificateType
 */
class CertificateType extends CertificateTypeType
{
} // end class CertificateType
