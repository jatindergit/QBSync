<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType CitySubdivisionNameType
 * @xmlName CitySubdivisionName
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\CitySubdivisionName
 */
class CitySubdivisionName extends CitySubdivisionNameType
{
} // end class CitySubdivisionName
