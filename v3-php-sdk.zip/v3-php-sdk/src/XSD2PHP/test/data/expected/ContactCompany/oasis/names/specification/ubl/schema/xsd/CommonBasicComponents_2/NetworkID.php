<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType NetworkIDType
 * @xmlName NetworkID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\NetworkID
 */
class NetworkID extends NetworkIDType
{
} // end class NetworkID
