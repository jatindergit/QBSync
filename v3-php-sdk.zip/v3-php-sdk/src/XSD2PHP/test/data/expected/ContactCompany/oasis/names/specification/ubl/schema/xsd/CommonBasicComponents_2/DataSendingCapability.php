<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType DataSendingCapabilityType
 * @xmlName DataSendingCapability
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\DataSendingCapability
 */
class DataSendingCapability extends DataSendingCapabilityType
{
} // end class DataSendingCapability
