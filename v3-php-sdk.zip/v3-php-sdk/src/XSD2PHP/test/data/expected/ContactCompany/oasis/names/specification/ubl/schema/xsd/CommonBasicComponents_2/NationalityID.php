<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType NationalityIDType
 * @xmlName NationalityID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\NationalityID
 */
class NationalityID extends NationalityIDType
{
} // end class NationalityID
