<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ChannelType
 * @xmlName Channel
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\Channel
 */
class Channel extends ChannelType
{
} // end class Channel
