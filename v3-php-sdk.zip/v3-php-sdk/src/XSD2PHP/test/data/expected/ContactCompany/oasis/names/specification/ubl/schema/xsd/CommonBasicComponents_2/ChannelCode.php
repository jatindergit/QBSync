<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ChannelCodeType
 * @xmlName ChannelCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\ChannelCode
 */
class ChannelCode extends ChannelCodeType
{
} // end class ChannelCode
