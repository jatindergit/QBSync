<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType InvoicingPartyReferenceType
 * @xmlName InvoicingPartyReference
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\InvoicingPartyReference
 */
class InvoicingPartyReference extends InvoicingPartyReferenceType
{
} // end class InvoicingPartyReference
