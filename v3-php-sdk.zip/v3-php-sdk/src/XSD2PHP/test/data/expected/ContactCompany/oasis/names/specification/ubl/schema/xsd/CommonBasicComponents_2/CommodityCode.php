<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType CommodityCodeType
 * @xmlName CommodityCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\CommodityCode
 */
class CommodityCode extends CommodityCodeType
{
} // end class CommodityCode
