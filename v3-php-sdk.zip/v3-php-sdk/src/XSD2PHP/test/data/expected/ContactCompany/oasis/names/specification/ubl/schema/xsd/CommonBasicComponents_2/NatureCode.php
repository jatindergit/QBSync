<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType NatureCodeType
 * @xmlName NatureCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\NatureCode
 */
class NatureCode extends NatureCodeType
{
} // end class NatureCode
