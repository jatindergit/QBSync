<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType MaximumCopiesNumericType
 * @xmlName MaximumCopiesNumeric
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\MaximumCopiesNumeric
 */
class MaximumCopiesNumeric extends MaximumCopiesNumericType
{
} // end class MaximumCopiesNumeric
