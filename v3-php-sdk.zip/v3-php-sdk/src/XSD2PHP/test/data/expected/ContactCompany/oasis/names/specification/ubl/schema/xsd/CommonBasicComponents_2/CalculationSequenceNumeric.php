<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType CalculationSequenceNumericType
 * @xmlName CalculationSequenceNumeric
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\CalculationSequenceNumeric
 */
class CalculationSequenceNumeric extends CalculationSequenceNumericType
{
} // end class CalculationSequenceNumeric
