<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType LocationIDType
 * @xmlName LocationID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\LocationID
 */
class LocationID extends LocationIDType
{
} // end class LocationID
