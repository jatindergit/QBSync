<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType MarkingIDType
 * @xmlName MarkingID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\MarkingID
 */
class MarkingID extends MarkingIDType
{
} // end class MarkingID
