<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType InsuranceValueAmountType
 * @xmlName InsuranceValueAmount
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\InsuranceValueAmount
 */
class InsuranceValueAmount extends InsuranceValueAmountType
{
} // end class InsuranceValueAmount
