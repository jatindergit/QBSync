<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ConditionType
 * @xmlName Condition
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\Condition
 */
class Condition extends ConditionType
{
} // end class Condition
