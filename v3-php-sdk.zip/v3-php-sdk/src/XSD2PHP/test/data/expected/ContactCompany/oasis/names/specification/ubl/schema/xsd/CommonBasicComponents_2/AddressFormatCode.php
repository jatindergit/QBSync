<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType AddressFormatCodeType
 * @xmlName AddressFormatCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\AddressFormatCode
 */
class AddressFormatCode extends AddressFormatCodeType
{
} // end class AddressFormatCode
