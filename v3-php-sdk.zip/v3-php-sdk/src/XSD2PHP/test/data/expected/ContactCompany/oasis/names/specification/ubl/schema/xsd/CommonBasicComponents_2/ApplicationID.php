<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ApplicationIDType
 * @xmlName ApplicationID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\ApplicationID
 */
class ApplicationID extends ApplicationIDType
{
} // end class ApplicationID
