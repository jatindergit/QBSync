<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType MedicalFirstAidGuideCodeType
 * @xmlName MedicalFirstAidGuideCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\MedicalFirstAidGuideCode
 */
class MedicalFirstAidGuideCode extends MedicalFirstAidGuideCodeType
{
} // end class MedicalFirstAidGuideCode
