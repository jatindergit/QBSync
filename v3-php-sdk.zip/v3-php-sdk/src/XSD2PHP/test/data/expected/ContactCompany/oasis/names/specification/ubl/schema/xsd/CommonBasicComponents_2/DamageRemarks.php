<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType DamageRemarksType
 * @xmlName DamageRemarks
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\DamageRemarks
 */
class DamageRemarks extends DamageRemarksType
{
} // end class DamageRemarks
