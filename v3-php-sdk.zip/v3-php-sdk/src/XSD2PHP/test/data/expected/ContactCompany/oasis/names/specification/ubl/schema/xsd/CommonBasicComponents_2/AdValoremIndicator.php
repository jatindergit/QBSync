<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType AdValoremIndicatorType
 * @xmlName AdValoremIndicator
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\AdValoremIndicator
 */
class AdValoremIndicator extends AdValoremIndicatorType
{
} // end class AdValoremIndicator
