<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType CarrierAssignedIDType
 * @xmlName CarrierAssignedID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\CarrierAssignedID
 */
class CarrierAssignedID extends CarrierAssignedIDType
{
} // end class CarrierAssignedID
