<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType BalanceAmountType
 * @xmlName BalanceAmount
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\BalanceAmount
 */
class BalanceAmount extends BalanceAmountType
{
} // end class BalanceAmount
