<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ActualDespatchTimeType
 * @xmlName ActualDespatchTime
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\ActualDespatchTime
 */
class ActualDespatchTime extends ActualDespatchTimeType
{
} // end class ActualDespatchTime
