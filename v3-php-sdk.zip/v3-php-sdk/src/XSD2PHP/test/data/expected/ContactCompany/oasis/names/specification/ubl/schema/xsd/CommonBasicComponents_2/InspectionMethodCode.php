<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType InspectionMethodCodeType
 * @xmlName InspectionMethodCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\InspectionMethodCode
 */
class InspectionMethodCode extends InspectionMethodCodeType
{
} // end class InspectionMethodCode
