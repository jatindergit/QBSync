<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType MarksType
 * @xmlName Marks
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\Marks
 */
class Marks extends MarksType
{
} // end class Marks
