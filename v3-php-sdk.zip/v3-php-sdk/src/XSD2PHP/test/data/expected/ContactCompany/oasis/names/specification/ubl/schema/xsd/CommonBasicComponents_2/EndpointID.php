<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType EndpointIDType
 * @xmlName EndpointID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\EndpointID
 */
class EndpointID extends EndpointIDType
{
} // end class EndpointID
