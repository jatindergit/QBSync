<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType EventCodeType
 * @xmlName EventCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\EventCode
 */
class EventCode extends EventCodeType
{
} // end class EventCode
