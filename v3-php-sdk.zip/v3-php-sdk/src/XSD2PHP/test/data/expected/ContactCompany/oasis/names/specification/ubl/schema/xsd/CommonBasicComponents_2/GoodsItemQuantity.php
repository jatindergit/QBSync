<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType GoodsItemQuantityType
 * @xmlName GoodsItemQuantity
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\GoodsItemQuantity
 */
class GoodsItemQuantity extends GoodsItemQuantityType
{
} // end class GoodsItemQuantity
