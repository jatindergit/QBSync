<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType CorporateRegistrationTypeCodeType
 * @xmlName CorporateRegistrationTypeCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\CorporateRegistrationTypeCode
 */
class CorporateRegistrationTypeCode extends CorporateRegistrationTypeCodeType
{
} // end class CorporateRegistrationTypeCode
