<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType CompanyIDType
 * @xmlName CompanyID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\CompanyID
 */
class CompanyID extends CompanyIDType
{
} // end class CompanyID
