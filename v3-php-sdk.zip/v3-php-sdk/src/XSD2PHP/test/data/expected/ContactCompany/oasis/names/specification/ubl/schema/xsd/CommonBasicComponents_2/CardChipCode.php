<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType CardChipCodeType
 * @xmlName CardChipCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\CardChipCode
 */
class CardChipCode extends CardChipCodeType
{
} // end class CardChipCode
