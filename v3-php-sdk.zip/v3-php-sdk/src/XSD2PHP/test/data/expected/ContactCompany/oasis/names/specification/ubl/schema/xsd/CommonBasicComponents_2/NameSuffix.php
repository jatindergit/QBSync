<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType NameSuffixType
 * @xmlName NameSuffix
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\NameSuffix
 */
class NameSuffix extends NameSuffixType
{
} // end class NameSuffix
