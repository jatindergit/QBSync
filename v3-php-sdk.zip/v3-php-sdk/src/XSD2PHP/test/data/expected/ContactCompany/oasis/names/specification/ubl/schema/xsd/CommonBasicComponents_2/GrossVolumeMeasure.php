<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType GrossVolumeMeasureType
 * @xmlName GrossVolumeMeasure
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\GrossVolumeMeasure
 */
class GrossVolumeMeasure extends GrossVolumeMeasureType
{
} // end class GrossVolumeMeasure
