<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType AdditionalStreetNameType
 * @xmlName AdditionalStreetName
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\AdditionalStreetName
 */
class AdditionalStreetName extends AdditionalStreetNameType
{
} // end class AdditionalStreetName
