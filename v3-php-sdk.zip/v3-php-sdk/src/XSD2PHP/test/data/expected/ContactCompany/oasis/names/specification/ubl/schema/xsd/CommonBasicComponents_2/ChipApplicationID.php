<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ChipApplicationIDType
 * @xmlName ChipApplicationID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\ChipApplicationID
 */
class ChipApplicationID extends ChipApplicationIDType
{
} // end class ChipApplicationID
