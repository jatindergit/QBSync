<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType DescriptionCodeType
 * @xmlName DescriptionCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\DescriptionCode
 */
class DescriptionCode extends DescriptionCodeType
{
} // end class DescriptionCode
