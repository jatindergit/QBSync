<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType DeclaredCustomsValueAmountType
 * @xmlName DeclaredCustomsValueAmount
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\DeclaredCustomsValueAmount
 */
class DeclaredCustomsValueAmount extends DeclaredCustomsValueAmountType
{
} // end class DeclaredCustomsValueAmount
